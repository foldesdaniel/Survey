/* eslint-disable no-unused-vars */

function Surveys() {
  return (
    <div style={{ textAlign: "center" }}>
      <h1 style={{ fontSize: "4rem", marginTop: "250px" }}>
        Welcome on the main page! 📨
      </h1>
    </div>
  );
}

export default Surveys;
